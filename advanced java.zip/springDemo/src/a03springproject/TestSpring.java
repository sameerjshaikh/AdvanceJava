package a03springproject;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpring {

	public static void main(String[] args) {
		// TODO Auto-generated method 	stub
		Presentation x =null;
		ClassPathXmlApplicationContext d=
				new ClassPathXmlApplicationContext("anything.xml");
		x = d.getBean(Presentation.class);
		x.startApp();
		
		
		

	}

}
