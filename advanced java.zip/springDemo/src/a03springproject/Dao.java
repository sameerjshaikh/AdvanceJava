package a03springproject;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class Dao {
	
	private JdbcTemplate t;
	

	public Dao() {
		
		BasicDataSource b = new BasicDataSource();
		b.setDriverClassName("com.mysql.cj.jdbc.Driver");
		b.setUsername("root");
		b.setPassword("");
		b.setUrl("jdbc:mysql://localhost:3306/test");
		t =new JdbcTemplate();
		t.setDataSource(b);
		// jdbctemplate now knows the datasource
		//hence obviously the connection information.
		
		
		// TODO Auto-generated constructor stub
		System.out.println("DAo created");
	}

	public Emp singleSelect(int i) {
		// TODO Auto-generated method stub
		String sql="select eid, ename,depid from employee where eid = ?";
		Object[] params = { i };
		BeanPropertyRowMapper<Emp> x =new BeanPropertyRowMapper<Emp>(Emp.class);
		
		Emp e;
		try {
			e = t.queryForObject(sql,params,x );
		} catch (DataAccessException e1) {
			// TODO Auto-generated catch block
			e=new Emp();
			e.setDepid(0);
			e1.printStackTrace();
			
		}
		
		return e;
		
		
	}

	public boolean updateEmpDetails(Emp e) {
		// TODO Auto-generated method stub
		String sql="update employee set ename=?,depid=? where eid=?";
		Object[] params = { e.getEname(),e.getDepid(),e.getEid() };
		int ra = t.update(sql,params);
				
		return ra > 0;
	}

	public List<Emp> multiSelectfromDB(int deptid) {
		// TODO Auto-generated method stub
		String sql =
				"select eid,ename ,depid from employee where depid=?";
		Object[] params= {deptid };
		List<Emp> l = null;
		BeanPropertyRowMapper<Emp> x =new BeanPropertyRowMapper<Emp>(Emp.class);
		try {
			l  = t.query(sql,params,x);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			l =new ArrayList<>();
		}
		
		return l;
	}
	
	
	

}
