package a03springproject;

import java.util.List;

public class Presentation {
	

	private Dao x;//this is we are doing and spring is not asking us

	public void setFreak(Dao dao) {
		
		System.out.println("dao wired in Presentation");
		this.x = dao;
		
		
	}

	public Presentation()
	{
		System.out.println("presentation object created");
	}

	public void startApp() {
		// TODO Auto-generated method stub
		//singleSelect();
		multiSelect();
		
		
	}

	private void multiSelect() {
		// TODO Auto-generated method stub
		int deptid =23;  // shwo sysout and scanner and ask which deptid employees you want to see.
		List<Emp>  l = x.multiSelectfromDB(deptid);// again function signature i decided when you will decide
		if(l.size() ==0)
			System.out.println(" no employee found in dept");
		else
			System.out.println(l);
		
		
		
		
		
		
		
		
	}

	private void singleSelect() {
		// TODO Auto-generated method stub
		int empno=2;
		Emp e  = x.singleSelect(empno);
		if(e.getDepid() == 0)
			System.out.println("empno is not found");
		else
		{
			System.out.println(e);
			String message ="\n show existing details to user" +
			"get updated details " + "store it in an object";
			System.out.println(message);
			e.setEname("xyz");
			e.setDepid(43);
			boolean status = x.updateEmpDetails(e);
			if(status)
				System.out.println("update succeeded");
			else
				System.out.println("update failed");
			
				
				
				
		}
	}

}
