package designPatterns.creational.factory;
 
public enum CarType {
    SMALL, SEDAN, LUXURY
}