package design2packge;

public interface Shape {
	   void draw();
	}