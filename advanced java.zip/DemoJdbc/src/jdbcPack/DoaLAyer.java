package jdbcPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DoaLAyer {
	

	final static String url = "jdbc:mysql://localhost:3306/jdbcDB";
	final static String user = "root";
	final static String pwd = "";
	
	static Connection getConnection() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, user, pwd);
		return con;
	}
	
	
	public static boolean searchdb(int a)
	{
		String query="select custid from customer where custid=?";
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, a);
			ResultSet rs=ps.executeQuery();
			
			
			if(rs.next())
			{
				
				return true;
				
				
			}
			else
			{
				Presentation.printMsg("Id Not Found in DB");
			}
			
			
			
		} catch (Exception e) {
			
			System.out.println(e);
			// TODO: handle exception
		}
		
		return false;
	}

	public static boolean addNewCustomer(int id,int pass,String rew,String cit) {
		
		String query="insert into customer(custid,password,rewards,city) values(?,?,?,?)";
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, id);
			ps.setInt(2, pass);
			ps.setString(3, rew);
			ps.setString(4, cit);
			int rs=ps.executeUpdate();
			
			if(rs!=0)
			{
				
				return true;
			}
			else
			{
				Presentation.printMsg("Data not added in table");
			}
			
			
		} catch (Exception e) {
			
			System.out.println(e);
			// TODO: handle exception
		}
		
		// TODO Auto-generated method stub
		return false;
	}

}
