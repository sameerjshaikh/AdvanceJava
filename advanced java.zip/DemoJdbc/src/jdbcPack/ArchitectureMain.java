package jdbcPack;

import java.util.Scanner;

public class ArchitectureMain {
	public static void main(String[] args) {
		
		ServiceLayer s1= new ServiceLayer();
		s1.FirstOperation();
		
		return ;
	}
	

	
	
	
}
