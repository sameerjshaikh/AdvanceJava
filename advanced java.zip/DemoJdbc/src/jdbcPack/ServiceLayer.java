package jdbcPack;

import java.util.ResourceBundle;

public class ServiceLayer {
	public void FirstOperation()
	{
	
	   int choice=Presentation.menu1();
	   
	   if(choice!=1)
	   {
		   return;
	   }
	   int cuid=Presentation.getNumber("Enter Admin Id ");
	   int pass=Presentation.getNumber("Enter password ");
	   
	   ResourceBundle r =ResourceBundle.getBundle("sys");
		int id=Integer.parseInt(r.getString("admin"));
		int password=Integer.parseInt(r.getString("password"));
		
		if(cuid==id && pass==password)
		{
			int a=Presentation.menu2();
			switch(a)
			{
			case 1:
				int ids=Presentation.getNumber("Enter Id ");
					serchFun(ids);
					break;
			case 2:
				
			case 3:	
			
			}
			 
		}
	   
	   
	   
	   
	   
	  
	   
	   
	   
	}

	private void serchFun(int a) {
		// TODO Auto-generated method stub
		
		boolean status=DoaLAyer.searchdb(a);
		
		if(status)
		{
			
		 
		}else {
			Presentation.printMsg("Add New Customer Details");
			 int newid=Presentation.getNumber("Enter Customer Id ");
			 int newpass=Presentation.getNumber("Enter password ");
			 String newreward=Presentation.getString("Enter Rewards");
			 String newcity=Presentation.getString("Enter  City");
			 
			 boolean status2=DoaLAyer.addNewCustomer(newid,newpass,newreward,newcity);
			 
		}
		
		
	}
}
