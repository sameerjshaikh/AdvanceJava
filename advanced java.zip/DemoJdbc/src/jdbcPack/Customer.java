package jdbcPack;

public class Customer {
	
	private int cutId;
	private int password;
	private int reward;
	private String city;
	public int getCutId() {
		return cutId;
	}
	public void setCutId(int cutId) {
		this.cutId = cutId;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public int getReward() {
		return reward;
	}
	public void setReward(int reward) {
		this.reward = reward;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	

}
