package jdbcPack;

import java.util.Scanner;

public class Presentation {

	static Scanner scan=new Scanner(System.in);
	public static int menu1() {
		
		System.out.println("1.Login \n0.Exit \nEnter Your choice");
		int a=scan.nextInt();
		return a;
	}
public static int menu2() {
		
		System.out.println("1.Enter Customer Id\n 2.Enter city \n 3.logoff");
		int a=scan.nextInt();
		return a;
	}
	

	public static int getNumber(String str)
	{
		printMsg(str);
		int num=scan.nextInt();
		return num;
	}
	
	public static void printMsg(Object str)
	{
		 System.out.println(str);
	}
	public static String getString(String str)
	{
		printMsg(str);
		String num=scan.next();
		return num;
	}

	
	
}
