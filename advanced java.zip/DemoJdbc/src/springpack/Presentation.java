package springpack;

import java.util.Scanner;

public class Presentation {

	private Doalayer x;//this is we are doing and spring is not asking us

	public void setFreak(Doalayer dao) {
		this.x = dao;
	
	}
	
	Scanner s=new Scanner(System.in);
	public void menu() {
		// TODO Auto-generated method stub
		System.out.println("Enter Customer Id");
		int id= s.nextInt();
		
		System.out.println("Enter password");
		int pwd= s.nextInt();
		
		System.out.println("Enter Rewards");
		int rewards= s.nextInt();
		
		System.out.println("Enter Customer City");
		String city= s.next();
		
		boolean b=x.insertDB(id,pwd,rewards,city);
		if(b)
			System.out.println("Data inserted Sussessfully");
		else {
			System.out.println("somthing wrong");
		}
		
		
	}
	public void menu2()
	{
		System.out.println("Enter id for update Detils");
		int idU= s.nextInt();
		
		
	}
	
	
	
	

}
