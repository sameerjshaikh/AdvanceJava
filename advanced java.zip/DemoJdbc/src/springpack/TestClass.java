package springpack;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestClass {
	
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext d=
				new ClassPathXmlApplicationContext("anything.xml");
		Presentation p1=  null;
		p1 = d.getBean(Presentation.class);
				p1.menu();
		
	}
	
			

}
