package springpack;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class Doalayer {
	
	private JdbcTemplate t;
	
	public Doalayer()
	{
		BasicDataSource b= new BasicDataSource();
		b.setDriverClassName("com.mysql.cj.jdbc.Driver");
		b.setUrl("jdbc:mysql://localhost:3306/springdb");
		b.setUsername("root");
		b.setPassword("");
		t=new JdbcTemplate();
		
		t.setDataSource(b);
	}

	public boolean insertDB(int id, int pwd, int rewards, String city) {
		// TODO Auto-generated method stub
		String query="insert into customer(id,pwd,rewards,city) values(?,?,?,?)";
		Object[] params = { id,pwd,rewards,city };
		int ra = t.update(query,params);
				
		return ra > 0;
	}

}
