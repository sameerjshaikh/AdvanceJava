package custom;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

public class CustomController {

	public String customFucntion(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String pagename = "/WEB-INF/customerResult.jsp";
		List<Customer> c = new ArrayList();
		c.add(new Customer(1,"sameer","pune"));
		c.add(new Customer(2,"abhishikt","nasirabad"));
		c.add(new Customer(3,"shahid","ranchi"));
		
		request.setAttribute("k1", c);
		
		return pagename;
	}

}
