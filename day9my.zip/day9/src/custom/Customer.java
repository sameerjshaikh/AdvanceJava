package custom;

public class Customer {
private int customerid;
private String name;
private String city;
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
	
	
}
public Customer(int customerid, String name, String city) {

	this.customerid = customerid;
	this.name = name;
	this.city = city;
}
public Customer() {
	
	// TODO Auto-generated constructor stub
}






}
