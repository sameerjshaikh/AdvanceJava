package servletPack;

import javax.servlet.http.HttpServletRequest;

public class OddEvenController {

	public String OddEvenFunction(HttpServletRequest request) {
		// TODO Auto-generated method stub
		
		String str=request.getParameter("num");
		int n=Integer.parseInt(str);
		String pagename;
		
		request.setAttribute("K1", n);
	   if(n%2==0)
	   {
		   request.setAttribute("K2", "Number is Even");
		   pagename="/WEB-INF/r1.jsp";
		  
		   
	   }
	   else
	   {
		   request.setAttribute("K2", "Number is ODD");
		    pagename="/WEB-INF/r1.jsp";
	   }
		
		
		return pagename;
	}

}
