package servletPack;

public class BController {

	public String controllerfunction() {
		// TODO Auto-generated method stub
		String pagename="/WEB-INF/c2.html";
		return pagename;
	}

}
