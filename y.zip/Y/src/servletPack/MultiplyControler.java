package servletPack;

import javax.servlet.http.HttpServletRequest;

public class MultiplyControler {

	public String MultiplyFunction(HttpServletRequest request) {
		// TODO Auto-generated method stub
		
		int num=Integer.parseInt(request.getParameter("num"));
		int n=num*num*num;
		String pagename;
		
		
		   request.setAttribute("K1",num);
		   request.setAttribute("K2",n);
		   
		   pagename="/WEB-INF/r3.jsp";
		  
	
		return pagename;
	}

}
