package servletPack;

public class AController {

	public String controllerFunction() {
		
		String pagename="/WEB-INF/c1.html";
		return pagename;
		// TODO Auto-generated method stub
		
	}

}
