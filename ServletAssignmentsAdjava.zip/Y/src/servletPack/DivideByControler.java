package servletPack;

import javax.servlet.http.HttpServletRequest;

public class DivideByControler {

	public String DivideByFunction(HttpServletRequest request) {
		// TODO Auto-generated method stub
		
		String str=request.getParameter("num");
		int n=Integer.parseInt(str);
		String pagename;
		
		request.setAttribute("K1", n);
	   if(n%7==0)
	   {
		   request.setAttribute("K2", "Number is Divisible By 7");
		   pagename="/WEB-INF/r1.jsp";
		  
		   
	   }
	   else
	   {
		   request.setAttribute("K2", "Number is Not Divisible By 7");
		    pagename="/WEB-INF/r1.jsp";
	   }
		
		
		return pagename;
	}

}
